Kepada para pengguna font Alphatara Arista, untuk pengetikan menggunakan font ini disesuaikan dengan keyboard huruf
Latin. Berikut daftar aksara:

A = a mandiri
B = bha
C = cha
D = dha
E = e-taling
F = -ai
G = nga
H = -h, ha mati
I = i mandiri
J = jha
K = kha
L = -r- (cakra)
M = mematikan konsonan (pangkon)
N = nya
O = o mandiri
P = pha
Q = gha
R = -r, ra mati (layar)
S = sya
T = tha
U = u mandiri
V = -ng, nga mati (cecak)
W = tanda untuk aksara serapan bahasa asing (Arab, Belanda, Inggris dll.)
X = sya/sha
Y = -ya (pengkal)
Z = dza (serapan Bahasa Arab--dzal)

a = ditiadakan, karena melebur pada konsonan
b = ba
c = ca
d = da
e = e-pepet
f = fa (serapan bahasa asing)
g = ga
h = ha
i = i
j = ja
k = ka
l = la
m = ma
n = na
o = o (tarung)
p = pa
q = qa (serapan Bahasa Arab--qaf)
r = ra
s = sa
t = ta
u = u
v = va (serapan bahasa asing)
w = wa
x = kha (serapan Bahasa Arab--kha)
y = ya
z = za (serapan bahasa asing)
^ = ddha
` = ttha
~ = nna
{ = pengapit judul sebelah kiri
} = pengapit judul sebelah kanan
[ = e-taling mandiri
[ = ai mandiri


